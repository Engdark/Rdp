import urllib3
import requests
import time
import threading
import sqlite3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import asyncio
from datetime import datetime


def load():
    conn = sqlite3.connect('acc.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            id TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    return cursor, conn

def get_all_accounts(limit=100):
    cursor, conn = load()
    cursor.execute('SELECT id, password FROM accounts LIMIT ?', (limit,))
    accounts = cursor.fetchall()
    return accounts

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Encrypt_ID(id):
    api_url = f"https://api-ghost.vercel.app/FFcrypto/{id}"
    response = requests.get(api_url)
    if response.status_code == 200:
        return response.text
    else:
        print("Failed to fetch data. Status code:", response.status_code)

def encrypt_api(plain_text):
    plain_text = bytes.fromhex(plain_text)
    key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
    cipher = AES.new(key, AES.MODE_CBC, iv)
    cipher_text = cipher.encrypt(pad(plain_text, AES.block_size))
    return cipher_text.hex()

def guest_token(uid, password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    headers = {"Host": "100067.connect.garena.com", "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)", "Content-Type": "application/x-www-form-urlencoded", "Accept-Encoding": "gzip, deflate, br", "Connection": "close",}
    data = {"uid": f"{uid}", "password": f"{password}", "response_type": "token", "client_type": "2", "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3", "client_id": "100067",}
    response = requests.post(url, headers=headers, data=data)
    data = response.json()
    NEW_ACCESS_TOKEN = data['access_token']
    NEW_OPEN_ID = data['open_id']
    return TOKEN_MAKER( NEW_ACCESS_TOKEN,NEW_OPEN_ID)

def TOKEN_MAKER(NEW_ACCESS_TOKEN ,NEW_OPEN_ID):
        now = datetime.now()
        formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
        PAYLOAD = b'\x1a\x132023-12-24 04:21:34"\tfree fire(\x01:\x081.108.14B2Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)J\x08HandheldR\rEMS - MobinilZ\x04WIFI`\x80\nh\xc0\x07r\x03320z\x1eARM64 FP ASIMD AES VMH | 0 | 6\x80\x01\xbf.\x8a\x01\x0fAdreno (TM) 640\x92\x01\rOpenGL ES 3.0\x9a\x01+Google|6ec2d681-b32f-4b2d-adc2-63b4c643d683\xa2\x01\x0e156.219.174.33\xaa\x01\x02ar\xb2\x01 55ed759fcf94f85813e57b2ec8492f5c\xba\x01\x014\xea\x01@6fb7fdef8658fd03174ed551e82b71b21db8187fa0612c8eaf1b63aa687f1eae\x9a\x06\x014\xa2\x06\x014\xf0\x01\x01\xca\x02\rEMS - Mobinil\xd2\x02\x04WIFI\xca\x03 7428b253defc164018c604a1ebbfebdf\xca\x03 7428b253defc164018c604a1ebbfebdf\xe0\x03\xe6\xdb\x02\xe8\x03\xff\xbb\x02\xf0\x03\xaf\x13\xf8\x03\xfc\x04\x80\x04\xaf\xca\x02\x88\x04\xe6\xdb\x02\x90\x04\xaf\xca\x02\x98\x04\xe6\xdb\x02\xc8\x04\x03\xd2\x04?/data/app/com.dts.freefireth-2kDmep_84HTIG7I7CUiJxw==/lib/arm64\xe0\x04\x01\xea\x04_df3bb3771c4b2d46f751a3e7d0347ba7|/data/app/com.dts.freefireth-2kDmep_84HTIG7I7CUiJxw==/base.apk\xf0\x04\x03\xf8\x04\x02\x8a\x05\x0264\x9a\x05\n2019116797\xa8\x05\x03\xb2\x05\tOpenGLES2\xb8\x05\xff\x7f\xc0\x05\x04\xca\x05 \x11\\\x10F\x07][\x05\x1e\x00XL\x0fXEZ\x149]R[]\x05b\nZ\t\x05`\x0eU5\xd2\x05\x0eShibin al Kawm\xda\x05\x03MNF\xe0\x05\xa6A\xea\x05\x07android\xf2\x05\\KqsHT+kkoTQE5BlBobUYX1gU2WQkP3UxRmOCvqs5/lkAGJsABcsIABFyS2oXUc9QDamooQF50iepFI53iz6yQPfFRAw=\xf8\x05\xac\x02'
        PAYLOAD = PAYLOAD.replace(b"6fb7fdef8658fd03174ed551e82b71b21db8187fa0612c8eaf1b63aa687f1eae" , NEW_ACCESS_TOKEN.encode("UTF-8"))
        PAYLOAD = PAYLOAD.replace(b"55ed759fcf94f85813e57b2ec8492f5c" , NEW_OPEN_ID.encode("UTF-8"))
        PAYLOAD = PAYLOAD.hex()
        PAYLOAD = encrypt_api(PAYLOAD)
        PAYLOAD = bytes.fromhex(PAYLOAD)
        URL = "https://loginbp.common.ggbluefox.com/MajorLogin"
        headers = {
            "Expect": "100-continue",
            "Authorization": "Bearer",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB47",
            "Content-Type": "application/x-www-form-urlencoded",
            "Content-Length": str(len(PAYLOAD.hex())),
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SM-N975F Build/PI)",
            "Host": "loginbp.common.ggbluefox.com",
            "Connection": "close",
            "Accept-Encoding": "gzip, deflate, br"
        }
        RESPONSE = requests.post(URL, headers=headers, data=PAYLOAD,verify=False)
        if RESPONSE.status_code == 200:
            if len(RESPONSE.text) < 10:
                return False
            BASE64_TOKEN = RESPONSE.text[RESPONSE.text.find("eyJhbGciOiJIUzI1NiIsInN2ciI6IjEiLCJ0eXAiOiJKV1QifQ"):-1]
            second_dot_index = BASE64_TOKEN.find(".", BASE64_TOKEN.find(".") + 1)
            BASE64_TOKEN = BASE64_TOKEN[:second_dot_index+44]
            return BASE64_TOKEN

def get_player_personal_show(id):
    url = f"https://api-info-bice.vercel.app/playerinfo/{id}"
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        basic_info = data.get("basicInfo", {})
        liked = basic_info.get("liked", "غير معروف")
        nickname = basic_info.get("nickname", "غير معروف")
        return nickname,liked
    else:
        return "فشل في جلب البيانات."

def attack(target_id,token):
    url = "https://clientbp.common.ggbluefox.com/GetPlayerPersonalShow"
    
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-GA": "v1 1",
        "ReleaseVersion": "OB43",
        "Host": "clientbp.common.ggbluefox.com",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "User-Agent": "Free%20Fire/2019117863 CFNetwork/1399 Darwin/22.1.0",
        "Connection": "keep-alive",
        "Authorization": f"Bearer {token}",
        "X-Unity-Version": "2018.4.11f1",
        "Accept": "*/*"
    }
    
    id_encrypted = Encrypt_ID(target_id)
    data0 = "08" + id_encrypted + "1007"
    data = bytes.fromhex(encrypt_api(data0))
    
    response = requests.post(url, headers=headers, data=data,verify=False)
    print(response)

async def start_like(target_id):
    accounts = get_all_accounts(limit=101)
    threads = []
    
    async def generate_token_and_send(uid, password):
        token = guest_token(uid, password)
        if token:
            attack(target_id, token)

    for account in accounts:
        uid, password = account
        thread = threading.Thread(target=asyncio.run, args=(generate_token_and_send(uid, password),))
        threads.append(thread)
        thread.start()
        time.sleep(0.05)

    for thread in threads:
        thread.join()

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.chat.type != "supergroup" and update.message.chat.type != "group":
        return
    
    if len(context.args) != 1 or not context.args[0].isdigit():
        await update.message.reply_text("Please Provide Valid Input\n/attack 12345678")
    else:
        target_id = context.args[0]
        
        message = await update.message.reply_text(f"Attacking {target_id} Please Wait...")
        
        await start_like(target_id)
        nickname, likes_before = get_player_personal_show(target_id) 
        await message.edit_text(f"Successfully Attack ☠️\nPlayer Nickname: {nickname}")

def main():
    application = ApplicationBuilder().token("7490259239:AAGn4r3p77o_CtMIYquk9Jkcu9k9o1oWu34").build()

    application.add_handler(CommandHandler("attack", like_command))

    application.run_polling()

if __name__ == "__main__":
    main()    